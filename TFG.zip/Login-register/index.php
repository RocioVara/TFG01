<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("location: bienvenida.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y registro - Rocío</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital@1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="estilos.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="encabezado">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
    </header>
    <main>
        <div class="contenedor__todo">
            <div class="caja__trasera">
                <div class="caja__trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div class="caja__trasera-register">
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Regístrate para que puedas iniciar sesión</p>
                    <button id="btn__registrarse">Registrarse</button>
                </div>
            </div>

            <div class="contenedor__login-register">
                <form id="loginForm" action="php/login_usuario_be.php" method="POST" class="formulario__login">
                    <h2>Iniciar Sesión</h2>
                    <input type="text" id="loginCorreo" placeholder="Correo Electronico" name="correo" required>
                    <div class="password-container">
                        <input type="password" id="loginContrasena" placeholder="Contraseña" name="contrasena" required>
                        <span class="toggle-password">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <button type="submit">Entrar</button>
                    <span id="loginError" style="color:red; display:none;"></span>
                </form>

                <form id="registroForm" action="php/registro_usuario_be.php" method="POST" class="formulario__register">
                    <h2>Regístrarse</h2>
                    <input type="text" id="nombre_completo" placeholder="Nombre completo" name="nombre_completo" required>
                    <input type="text" id="correo" placeholder="Correo Electronico" name="correo" required>
                    <input type="text" id="usuario" placeholder="Usuario" name="usuario" required>
                    <div class="password-container">
                        <input type="password" id="contrasena" placeholder="Contraseña" name="contrasena" required>
                        <span class="toggle-password">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <button type="submit">Registrar</button>
                    <span id="correoError" style="color:red; display:none;"></span>
                    <span id="contrasenaError" style="color:red; display:none;"></span>
                </form>
                <a href="perfil.php">Ir a mi perfil</a>
            </div>
        </div>
    </main>
    <script src="js/script.js"></script>
    <script src="js/validaciones.js"></script>
</body>
</html>
