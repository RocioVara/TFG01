<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recomendaciones de Productos</title>
    <link rel="stylesheet" href="../css/recomendaciones.css">
</head>
<body>
    <header class="main-header">
        <img src="../imgs/pancakes.webp" alt="Fondo del encabezado">
        <div class="container">
            <h1>Los Mejores Productos</h1>
            <p>Según tu Objetivo</p>
        </div>
    </header>

    <main>
        <h1>Productos Recomendados</h1>
        <div class="tabs">
            <button class="tab-button active">Proteínas</button>
            <button class="tab-button">Carbohidratos</button>
            <button class="tab-button">Grasas</button>
        </div>
        <div id="mejores-productos" class="productos-container"></div>
    </main>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const urlParams = new URLSearchParams(window.location.search);
            const objetivo = urlParams.get('objetivo');

            function getHoverText(nombre) {
                switch (nombre) {
                    case 'Hummus':
                        return 'Buena opción en dietas de volumen veganas y vegetarianas';
                    case 'Yogur griego natural':
                        return 'En comparación con el yogur natural regular, suele contener más grasa, debido al proceso de filtrado utilizado en su producción';
                    case 'Natillas proteicas':
                        return 'Buena opción como postre, puedes agregar canela para realzar su sabor';
                    case 'Crema de cacahuete 100%':
                        return 'Más fácil de consumir que los frutos secos enteros, la crema de cacahuete es ideal para volumen muscular, ya que no produce tanta saciedad';
                    case 'Gelatina 0% azúcar sabor fresa':
                        return 'Buena opción en fase de definición si tienes antojo de dulce, debido a su poco aporte calórico';
                    case 'Claras de huevo':
                        return 'Proteína de alto valor biológico';
                    case 'Queso fresco':
                        return 'Fuente de calcio';
                    case 'Pan de fibra y sésamo':
                        return 'Las semillas de sésamo son una fuente rica de ácidos grasos esenciales';
                    case 'Crema de arroz':
                        return 'La glucosa que aporta este alimento se almacena en nuestros músculos para tener fuerza a la hora de entrenar';
                    case 'Cereal Mix':
                        return 'Esta combinación de cereales son ideales para aportar hidratos de carbono de bajo índice glucémico';
                    default:
                        return 'Detalles adicionales';
                }
            }

            if (objetivo) {
                fetch(`../php/mostrar_alimentos_recomendados.php?objetivo=${objetivo}`)
                    .then(response => response.json())
                    .then(data => {
                        const contenedor = document.getElementById('mejores-productos');
                        if (data.error) {
                            contenedor.innerHTML = `<p>Error: ${data.error}</p>`;
                        } else {
                            data.forEach(producto => {
                                const productoDiv = document.createElement('div');
                                const imagenClase = (producto.nombre === 'Crema de arroz' || producto.nombre === 'Cereal Mix') ? 'ajustada' : '';
                                productoDiv.className = 'producto';
                                productoDiv.innerHTML = `
                                    <div class="producto-imagen ${imagenClase}">
                                        <img src="${producto.imagen}" alt="${producto.nombre}">
                                        <div class="producto-hover">
                                            <h3>${getHoverText(producto.nombre)}</h3>
                                        </div>
                                    </div>
                                    <div class="producto-detalle">
                                        <h2>${producto.nombre}</h2>
                                        <p class="descripcion">${producto.descripcion}</p>
                                        <p class="marca">Marca: ${producto.marca}</p>
                                        <p class="precio">€${producto.precio}</p>
                                    </div>
                                `;
                                contenedor.appendChild(productoDiv);
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching the data:', error);
                    });
            } else {
                document.getElementById('mejores-productos').innerHTML = '<p>Error: No se proporcionó un objetivo.</p>';
            }
        });
    </script>
</body>
</html>
