<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    echo '
    <script>
        alert("Por favor, inicia sesión");
        window.location = "../index.php";
    </script>
    ';

    session_destroy();
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Objetivos</title>
    <link rel="stylesheet" href="../estilos.css"> <!-- Ajusta la ruta según la ubicación de tu archivo CSS -->
</head>
<body>
    <header class="encabezado">
        <div class="logo">
            <img src="../logo.png" alt="Logo">
        </div>
    </header>
    <main>
        <h1>Selecciona tus objetivos</h1>
        <form action="../html/recomendaciones.php" method="GET"> <!-- Cambio de action a recomendaciones.php -->
            <input type="radio" id="perdida_grasa" name="objetivo" value="1">
            <label for="perdida_grasa">Pérdida de grasa</label><br>
            <input type="radio" id="aumento_masa_muscular" name="objetivo" value="2">
            <label for="aumento_masa_muscular">Aumento de masa muscular</label><br>
            <button type="submit">Enviar</button>
        </form>
    </main>
</body>
</html>
