<?php
include 'conexion_be.php';

// Consulta SQL para obtener la lista de usuarios incluyendo la contraseña
$query = "SELECT id, nombre_completo, correo, usuario, contrasena FROM usuarios";
$resultado = mysqli_query($conexion, $query);

if ($resultado && mysqli_num_rows($resultado) > 0) {
    echo '<h1>Listado de Usuarios</h1>';
    echo '<table border="1">';
    echo '<tr><th>ID</th><th>Nombre Completo</th><th>Correo</th><th>Usuario</th><th>Contraseña</th><th>Acciones</th></tr>';

    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo '<tr>';
        echo '<td>' . $fila['id'] . '</td>';
        echo '<td>' . $fila['nombre_completo'] . '</td>';
        echo '<td>' . $fila['correo'] . '</td>';
        echo '<td>' . $fila['usuario'] . '</td>';
        echo '<td>' . substr($fila['contrasena'], 0, 10) . '...</td>';
        echo '<td>';
        echo '<a href="borrar_usuario.php?id=' . $fila['id'] . '">Borrar</a>';
        echo ' | ';
        echo '<a href="modificar_usuario.php?id=' . $fila['id'] . '">Modificar</a>';
        echo '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo 'No hay usuarios para mostrar.';
}

mysqli_close($conexion);
?>
