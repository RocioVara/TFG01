<?php
// Incluir el archivo de conexión a la base de datos de nutrición
include 'conexion_nutricion.php'; 

// Verificar si se ha proporcionado un objetivo en la URL
if (isset($_GET["objetivo"])) {
    // Obtener el objetivo de la URL
    $objetivo = $_GET["objetivo"];

    // Consultar los alimentos recomendados para el objetivo proporcionado
    $query = "SELECT * FROM alimentos WHERE objetivo_id = ?";
    $stmt = mysqli_prepare($conexion_nutricion, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $objetivo);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Crear un array para almacenar los alimentos recomendados
        $alimentos = array();

        // Agregar cada fila de resultados al array de alimentos
        while ($row = mysqli_fetch_assoc($result)) {
            // Asignar una URL de imagen basada en el nombre del alimento
            switch ($row['nombre']) {
                case 'Hummus':
                    $imagen = '../imgs/hummus2.jpg';
                    break;
                case 'Pan de fibra y sésamo':
                    $imagen = '../imgs/pan_fibra.jpg';
                    break;
                case 'Queso fresco':
                    $imagen = '../imgs/queso_fresco.jpg';
                    break;
                    case 'Natillas proteicas':
                        $imagen = '../imgs/natillas.jpg';
                        break;
                case 'Yogur griego natural':
                    $imagen = '../imgs/yogur_griego.jpg';
                    break;                   
                case 'Claras de huevo':
                    $imagen = '../imgs/clara.jpg';
                    break;
                case 'Gelatina 0% azúcar sabor fresa':
                    $imagen = '../imgs/gelatina.jpg';
                    break;
                case 'Crema de cacahuete 100%':
                    $imagen = '../imgs/c_cacahuete.jpg';
                    break;
                case 'Crema de arroz':
                    $imagen = '../imgs/crema_arroz.jpg';
                    break;
                case 'Cereal Mix':
                    $imagen = '../imgs/cereales_mix.jpg';
                    break;
                default:
                    $imagen = '../imgs/chocolatina_85.webp';
                    break;
            }
            
            $hover_text = '';
            switch ($row['nombre']) {
                case 'Hummus':
                    $hover_text = 'Buena opción en dietas de volumen veganas y vegetarianas';
                    break;
                case 'Yogur griego natural':
                    $hover_text = 'En comparación con el yogur natural regular, suele contener más grasa, debido al proceso de filtrado utilizado en su producción';
                    break;
                case 'Natillas proteicas':
                    $hover_text = 'Buena opción como postre, puedes agregar canela para realzar su sabor';
                    break;
                case 'Crema de cacahuete 100%':
                    $hover_text = 'Más fácil de consumir que los frutos secos enteros, la crema de cacahuete es ideal para volumen muscular, ya que no produce tanta saciedad';
                    break;
                case 'Gelatina 0% azúcar sabor fresa':
                    $hover_text = 'Buena opción en fase de definición si tienes antojo de dulce, debido a su poco aporte calórico';
                    break;
                case 'Claras de huevo':
                    $hover_text = 'Proteína de alto valor biológico';
                    break;
                case 'Queso fresco':
                    $hover_text = 'Fuente de calcio';
                    break;
                case 'Pan de fibra y sésamo':
                    $hover_text = 'Las semillas de sésamo son una fuente rica de ácidos grasos esenciales';
                    break;
                case 'Crema de arroz':
                    $hover_text = 'La glucosa que aporta este alimento se almacena en nuestros músculos para tener fuerza a la hora de entrenar';
                    break;
                case 'Cereal Mix':
                    $hover_text = 'Esta combinación de cereales son ideales para aportar hidratos de carbono de bajo índice glucémico';
                    break;
                default:
                    $hover_text = 'Detalles adicionales';
                    break;
            }

            $alimento = array(
                'nombre' => $row['nombre'],
                'descripcion' => $row['descripcion'],
                'precio' => $row['precio'],
                'marca' => $row['marca'],
                'imagen' => $imagen,  // Usar la URL de la imagen asignada
                'hover_text' => $hover_text
            );
            $alimentos[] = $alimento;
        }

        // Devolver los alimentos en formato JSON
        echo json_encode($alimentos);

        mysqli_stmt_close($stmt);
    } else {
        // Manejar errores de consulta
        echo json_encode(array('error' => mysqli_error($conexion_nutricion)));
    }
} else {
    // Manejar si no se proporciona un objetivo
    echo json_encode(array('error' => 'No se proporcionó un objetivo.'));
}

// Cierra la conexión a la base de
