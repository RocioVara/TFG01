<?php
session_start();
include 'conexion_be.php';

$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];
$contrasena = hash('sha512', $contrasena);

$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo' AND contrasena='$contrasena'");

if (mysqli_num_rows($validar_login) > 0) {
    $row = mysqli_fetch_assoc($validar_login);

    $_SESSION['usuario'] = $correo;

    if ($row['correo'] == 'admin@gmail.com') {
        // Redirigir al administrador a la página de bienvenida
        header("location: ../bienvenida.php");
    } else {
        // Redirigir a los usuarios normales al formulario de objetivos
        header("location: ../php/formulario_objetivos.php");
    }
    exit;
} else {
    echo '
    <script>
        alert("Usuario no existe, por favor verifique los datos introducidos");
        window.location = "../index.php";
    </script>
    ';
    exit;
}
?>
