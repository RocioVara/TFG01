document.addEventListener('DOMContentLoaded', function () {
    // Validación de formulario de registro
    document.getElementById('registroForm').addEventListener('submit', function (event) {
        const correo = document.getElementById('correo').value;
        const contrasena = document.getElementById('contrasena').value;
        const nombre_completo = document.getElementById('nombre_completo').value;
        const usuario = document.getElementById('usuario').value;
        const errorCorreo = document.getElementById('correoError');
        const errorContrasena = document.getElementById('contrasenaError');

        errorCorreo.textContent = '';
        errorContrasena.textContent = '';

        if (!nombre_completo || !correo || !usuario || !contrasena) {
            alert('Todos los campos son obligatorios');
            event.preventDefault();
        } else if (!validateEmail(correo)) {
            alert('Por favor, introduce un correo válido');
            errorCorreo.textContent = 'Correo no válido';
            errorCorreo.style.display = 'block';
            event.preventDefault();
        } else if (contrasena.length < 8 || !/[!@#$%^&*]/.test(contrasena) || !/\d/.test(contrasena)) {
            alert('La contraseña debe tener al menos 8 caracteres, incluyendo un número y un carácter especial');
            errorContrasena.textContent = 'La contraseña debe tener al menos 8 caracteres, incluyendo un número y un carácter especial';
            errorContrasena.style.display = 'block';
            event.preventDefault();
        }
    });

    // Validación de formulario de inicio de sesión
    document.getElementById('loginForm').addEventListener('submit', function (event) {
        const loginCorreo = document.getElementById('loginCorreo').value;
        const loginContrasena = document.getElementById('loginContrasena').value;
        const loginError = document.getElementById('loginError');

        loginError.textContent = '';

        if (!loginCorreo || !loginContrasena) {
            alert('Todos los campos son obligatorios');
            loginError.textContent = 'Todos los campos son obligatorios';
            loginError.style.display = 'block';
            event.preventDefault();
        } else if (!validateEmail(loginCorreo)) {
            alert('Por favor, introduce un correo válido');
            loginError.textContent = 'Correo no válido';
            loginError.style.display = 'block';
            event.preventDefault();
        }
    });

    // Mostrar/Ocultar contraseña
    document.querySelectorAll('.toggle-password').forEach(item => {
        item.addEventListener('click', function () {
            const input = this.previousElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                this.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                input.type = 'password';
                this.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    });

    // Validación de correo electrónico
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }
});
