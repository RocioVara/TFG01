<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    echo '
    <script>
        alert("Por favor, inicia sesión");
        window.location = "index.php";
    </script>
    ';

    session_destroy();
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenida - Rocío</title>
    <link rel="stylesheet" href="estilos_bienvenida.css">
</head>
<body>
    <header class="encabezado">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
    </header>
    <main>
        <h1>Bienvenido a mi web</h1>
        <a href="php/listado_usuarios.php">Listar usuarios</a>
        <br>
        <a href="php/alta_usuario.php">Alta usuario</a>
        <br>
        <a href="php/cerrar_sesion.php">Cerrar sesión</a>
        <br>
    </main>
</body>
</html>
